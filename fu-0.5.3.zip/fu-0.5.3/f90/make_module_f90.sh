rm fucubelib.so
f2py -c fucubelib.pyf fucubelib.f90

