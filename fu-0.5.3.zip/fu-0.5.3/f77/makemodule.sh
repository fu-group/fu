Echo change python path for your system and set path to access gnu frotran compiler 
python /opt/local/Library/Frameworks/Python.framework/Versions/2.7/bin/f2py -c fortlib.pyf fortlib.f --fcompiler=gnu95 --compiler=mingw32
